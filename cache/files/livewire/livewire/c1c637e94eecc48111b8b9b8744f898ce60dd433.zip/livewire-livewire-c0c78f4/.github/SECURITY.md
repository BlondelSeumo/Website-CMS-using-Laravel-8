# Security Policy

**PLEASE DON'T DISCLOSE SECURITY-RELATED ISSUES PUBLICLY.**

## Reporting a Vulnerability

If you discover a security vulnerability within Livewire, please send an email to Caleb Porzio at calebporzio@gmail.com. All security vulnerabilities will be promptly addressed.
