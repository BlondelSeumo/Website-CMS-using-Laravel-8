<?php

namespace League\OAuth1\Client\Credentials;

class TokenCredentials extends Credentials implements CredentialsInterface
{
}
