<?php

namespace Laravel\Fortify\Contracts;

use Illuminate\Contracts\Support\Responsable;

interface TwoFactorLoginResponse extends Responsable
{
    //
}
