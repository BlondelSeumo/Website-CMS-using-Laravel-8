# Inertia.js Laravel Adapter

Visit [inertiajs.com](https://inertiajs.com/) to learn more.
